# CTOON Kodi
A simple Kodi video addon for streaming cartoon episodes from [ctoon.party](https://ctoon.party).  
Install it from [this zip here](https://github.com/doko-desuka/plugin.video.ctoonkodi/raw/master/plugin.video.ctoonkodi-0.4.2.zip), or install from [my repository](https://github.com/dokoab/doko.repository/releases) to get automatic updates.  

Help keep CTOON alive, donate to the host: [ko-fi.com/A637AV5](https://ko-fi.com/A637AV5)

Pull-requests are always welcome.

![screenshot](https://images2.imgbox.com/84/73/s34C3pVv_o.png)
