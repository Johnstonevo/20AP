''' Basic objects package structure. 
	Used to initially setup objects when it is the first time.
'''
version = "DEFAULT"

