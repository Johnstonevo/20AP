rsync -avix --progress --exclude-from '.git' ../XBMC-CloudStream/* repo/plugin.video.cloudstream
