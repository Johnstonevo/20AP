rsync -avix --progress --exclude-from '.git' ../ownCloud-for-KODI/* repo/plugin.video.owncloud
