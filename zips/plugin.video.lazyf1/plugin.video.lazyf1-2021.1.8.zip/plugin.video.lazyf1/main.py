import sys

if __name__ == '__main__':
	from lib import interface
	interface.plugin.run()