---
name: Add new content
about: Suggest an new content (TV channel, website, radio) to add
title: ''
labels: Add new content
assignees: ''

---

### Content description

* Name:
* Type [e.g. TV channel, Catch-up TV, Website, Radio]:
* Website URL:
* Content language/country:

### Content access

- [ ] This content or some part of this content require a free account
- [ ] This content or some part of this content require a paid account
- [ ] This content is geographically restricted

### More information

If you want to add more information, put it here:
