# WatchNixtoons2

A Kodi video add-on for streaming cartoons and anime from [watchcartoononline.io](https://www.watchcartoononline.io).   
Help the WatchCartoonOnline website by making a donation to their PayPal at: wcohelp\@yandex\.com (verify the address [on this page](https://www.watchcartoononline.io/contact)).  

Install it from [this zip here](https://github.com/doko-desuka/plugin.video.watchnixtoons2/raw/master/plugin.video.watchnixtoons2-0.3.0.zip) or from [my repository](https://github.com/doko-desuka/doko.repository/releases) to get automatic updates.  
Pull-requests are always welcome.

![screenshot](https://images2.imgbox.com/b1/7a/wmdubsNr_o.png)  
