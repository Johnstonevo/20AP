streaming_subreddits = [
{'name': 'Boxing Streams', 'url': 'BoxingStreams'},
{'name': 'Rugby Streams', 'url': 'RugbyStreams'},
{'name': 'Motor Sports Streams', 'url': 'motorsportsstreams'},
{'name': 'Soccer Streams', 'url': 'soccerstreams'},
{'name': 'MMA Streams', 'url': 'MMAStreams'},
]

