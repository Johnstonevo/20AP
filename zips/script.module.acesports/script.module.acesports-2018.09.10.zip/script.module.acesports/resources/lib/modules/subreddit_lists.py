streaming_subreddits = [
{'name': 'Boxing Streams', 'url': 'BoxingStreams'},
{'name': 'Rugby Streams', 'url': 'RugbyStreams'},
{'name': 'Motor Sports Streams', 'url': 'motorsportsstreams'},
{'name': 'Live Tv Links', 'url': 'LiveTvLinks'},
]

